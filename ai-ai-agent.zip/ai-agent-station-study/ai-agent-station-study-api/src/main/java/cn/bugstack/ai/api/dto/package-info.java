/**
 * 数据传输对象 xxxRequestDTO xxxResponseDTO
 */
package cn.bugstack.ai.api.dto;