/**
 * 定义api接口
 */
package cn.bugstack.ai.api;