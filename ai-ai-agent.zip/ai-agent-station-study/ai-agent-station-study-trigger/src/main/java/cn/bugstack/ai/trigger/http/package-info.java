/**
 * HTTP 接口服务
 */
package cn.bugstack.ai.trigger.http;