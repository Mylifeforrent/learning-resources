/**
 * 任务服务，可以选择使用 Spring 默认提供的 Schedule https://bugstack.cn/md/road-map/quartz.html
 */
package cn.bugstack.ai.trigger.job;