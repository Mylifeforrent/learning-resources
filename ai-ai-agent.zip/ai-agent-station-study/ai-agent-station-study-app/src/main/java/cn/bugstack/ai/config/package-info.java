/**
 * 1. 用于管理引入的Jar所需的资源启动或者初始化处理
 * 2. 如果有AOP切面，可以再建一个aop包，来写切面逻辑
 */
package cn.bugstack.ai.config;

