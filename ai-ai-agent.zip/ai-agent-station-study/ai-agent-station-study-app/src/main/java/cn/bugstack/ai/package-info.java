/**
 * 应用启动层，注意Application所在的包路径，是在上一层。这样才能扫描到其他 module
 * */
package cn.bugstack.ai;