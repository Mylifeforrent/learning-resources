/**
 * 仓储服务
 * 1. 定义仓储接口，之后由基础设施层做具体实现
 */
package cn.bugstack.ai.domain.agent.adapter.repository;