/**
 * 值对象；
 * 1. 用于描述对象属性的值，如一个库表中有json后者一个字段多个属性信息的枚举对象
 * 2. 对象名称如；XxxVO
 */
package cn.bugstack.ai.domain.agent.model.valobj;