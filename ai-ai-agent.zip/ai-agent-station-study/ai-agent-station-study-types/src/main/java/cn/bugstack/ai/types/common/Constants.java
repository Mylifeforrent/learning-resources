package cn.bugstack.ai.types.common;

public class Constants {

    public final static String SPLIT = ",";

}
