/**
 * 提供redis链接配置
 */
package cn.bugstack.ai.infrastructure.redis;