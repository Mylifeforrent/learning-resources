/**
 * 定义http、rpc接口，调用外部。在 adapter 中调用这部分内容。
 */
package cn.bugstack.ai.infrastructure.gateway;