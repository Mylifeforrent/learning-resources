/**
 * 仓储实现；用于实现 domain 中定义的仓储接口，如；IXxxRepository 在 Repository 中调用服务
 */
package cn.bugstack.ai.infrastructure.adapter.repository;