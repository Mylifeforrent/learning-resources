/**
 * 实现对外部的api调用，类的名称为 XxxPort 接口定义在 domain 中
 */
package cn.bugstack.ai.infrastructure.adapter.port;