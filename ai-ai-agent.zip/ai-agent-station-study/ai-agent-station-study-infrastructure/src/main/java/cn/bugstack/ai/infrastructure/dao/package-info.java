/**
 * DAO 接口；IXxxDao
 */
package cn.bugstack.ai.infrastructure.dao;