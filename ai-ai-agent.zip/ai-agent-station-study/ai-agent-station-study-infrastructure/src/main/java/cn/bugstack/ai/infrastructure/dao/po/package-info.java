/**
 * 持久化对象；XxxPO 最后的 PO 是大写，UserPO
 */
package cn.bugstack.ai.infrastructure.dao.po;